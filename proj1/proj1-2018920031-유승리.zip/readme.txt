[Project #1: Implementing Luxo]
2018920031 유승리

사용한 릴리즈 버전: r134

구현 성공한 것: 모든 요구사항을 구현하였습니다.
- luxo lamp
- 조작 가능한 GUI (min/max/step 값 적용)
- 전구 (spot light)
- 4개의 3D models 및 그림자

구현 실패한 것: 없습니다.